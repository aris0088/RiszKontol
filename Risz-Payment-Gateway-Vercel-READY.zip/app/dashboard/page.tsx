
export default function Dashboard() {
  return (
    <div className="p-10">
      <h1 className="text-3xl font-bold">Dashboard</h1>
      <div className="mt-6 space-y-2">
        <p>Saldo: Rp 0</p>
        <p>Total Deposit: Rp 0</p>
        <p>Total Withdraw: Rp 0</p>
        <p className="break-all">API Key: **************</p>
      </div>
    </div>
  )
}
